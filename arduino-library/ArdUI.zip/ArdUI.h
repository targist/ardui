#pragma once

bool read_program_bytes();

int execute_setup();

int execute_loop();
