#pragma once

void deserializeProgram();

void runSetupInstructions();

void runLoopInstructions();

bool readBuffer();
